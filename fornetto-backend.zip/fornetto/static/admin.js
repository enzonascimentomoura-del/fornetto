(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const CSRF = $('meta[name=csrf]').content;
  const brl = v => Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const dataBR = iso => iso.slice(0, 10).split('-').reverse().join('/');
  const hora = iso => iso.slice(11, 16);

  function el(tag, props = {}, ...filhos) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
    filhos.flat().forEach(f => f != null && e.append(f));
    return e;
  }

  async function api(metodo, url, corpo) {
    const opts = { method: metodo, headers: { 'X-CSRF-Token': CSRF } };
    if (corpo instanceof FormData) opts.body = corpo;
    else if (corpo) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(corpo); }
    const r = await fetch(url, opts);
    if (r.status === 401) { location.href = '/admin/login'; throw new Error('Sessão expirada'); }
    const d = await r.json().catch(() => ({}));
    if (!r.ok || d.ok === false) throw new Error(d.erro || 'Erro inesperado.');
    return d;
  }
  const falha = e => alert(e.message);

  const ROT = {
    novo: 'Novo', em_preparo: 'Em preparo', saiu_entrega: 'Saiu p/ entrega', concluido: 'Concluído', cancelado: 'Cancelado',
    pendente: 'Pendente', confirmada: 'Confirmada', cancelada: 'Cancelada', aprovada: 'Aprovada', rejeitada: 'Rejeitada',
  };
  const CAT = { tradicional: 'Tradicional', especial: 'Especial', veggie: 'Vegetariana', doce: 'Doce', rodizio: 'Rodízio' };

  function seletorStatus(atual, opcoes, aoMudar) {
    const s = el('select', {}, opcoes.map(o => el('option', { value: o, text: ROT[o], ...(o === atual ? { selected: '' } : {}) })));
    s.addEventListener('change', () => aoMudar(s.value));
    return s;
  }

  const raiz = $('#conteudo');
  let aba = 'pedidos', timer = null;

  // ---------------------------------------------------------------- pedidos
  async function abaPedidos() {
    const lista = await api('GET', '/admin/api/pedidos');
    raiz.replaceChildren(...(lista.length ? lista.map(p => el('div', { class: 'card' },
      el('div', { class: 'linha' },
        el('h3', { text: `#${p.id} · ${p.nome} · ${brl(p.total)}` }),
        seletorStatus(p.status, ['novo', 'em_preparo', 'saiu_entrega', 'concluido', 'cancelado'],
          async v => { try { await api('PATCH', `/admin/api/pedidos/${p.id}`, { status: v }); contadores(); } catch (e) { falha(e); } })),
      el('div', { class: 'meta', text: `${dataBR(p.criado_em)} ${hora(p.criado_em)} · ${p.telefone} · ${p.tipo === 'entrega' ? 'Entrega: ' + p.endereco : 'Retirada'} · ${p.pagamento || 'pagamento n/i'}` }),
      el('ul', {}, p.itens.map(i => el('li', { text: `${i.qtd}x ${i.nome} — ${brl(i.preco * i.qtd)}` }))),
      p.taxa_entrega ? el('div', { class: 'meta', text: `Taxa de entrega: ${brl(p.taxa_entrega)}` }) : null,
      p.observacao ? el('div', { class: 'meta', text: `Obs: ${p.observacao}` }) : null,
    )) : [el('p', { class: 'vazio', text: 'Nenhum pedido ainda.' })]));
  }

  // ---------------------------------------------------------------- reservas
  async function abaReservas() {
    const lista = await api('GET', '/admin/api/reservas');
    raiz.replaceChildren(...(lista.length ? lista.map(r => el('div', { class: 'card' },
      el('div', { class: 'linha' },
        el('h3', { text: `${dataBR(r.data)} às ${r.horario} · ${r.nome} · ${r.pessoas} pessoa(s)` }),
        seletorStatus(r.status, ['pendente', 'confirmada', 'cancelada'],
          async v => { try { await api('PATCH', `/admin/api/reservas/${r.id}`, { status: v }); contadores(); } catch (e) { falha(e); } })),
      el('div', { class: 'meta', text: `Tel.: ${r.telefone} · solicitada em ${dataBR(r.criado_em)}` }),
      r.observacao ? el('div', { class: 'meta', text: `Obs: ${r.observacao}` }) : null,
    )) : [el('p', { class: 'vazio', text: 'Nenhuma reserva ainda.' })]));
  }

  // ---------------------------------------------------------------- avaliações
  async function abaAvaliacoes() {
    const lista = await api('GET', '/admin/api/avaliacoes');
    const mudar = (id, status) => async () => { try { await api('PATCH', `/admin/api/avaliacoes/${id}`, { status }); mostrar(); } catch (e) { falha(e); } };
    raiz.replaceChildren(...(lista.length ? lista.map(a => el('div', { class: 'card' },
      el('div', { class: 'linha' },
        el('h3', { text: `${'★'.repeat(a.estrelas)} ${a.nome}` }),
        el('span', { class: 'meta', text: `${ROT[a.status]} · ${dataBR(a.criado_em)}` })),
      el('p', { text: a.texto }),
      el('div', { class: 'linha', style: 'justify-content:flex-start' },
        a.status !== 'aprovada' ? el('button', { class: 'b ok', text: 'Aprovar', onclick: mudar(a.id, 'aprovada') }) : null,
        a.status !== 'rejeitada' ? el('button', { class: 'b sec', text: 'Rejeitar', onclick: mudar(a.id, 'rejeitada') }) : null,
        el('button', { class: 'b', text: 'Excluir', onclick: async () => {
          if (!confirm('Excluir esta avaliação definitivamente?')) return;
          try { await api('DELETE', `/admin/api/avaliacoes/${a.id}`); mostrar(); } catch (e) { falha(e); }
        } })),
    )) : [el('p', { class: 'vazio', text: 'Nenhuma avaliação.' })]));
  }

  // ---------------------------------------------------------------- cardápio
  const dlg = $('#dlg-produto'), form = $('#form-produto'), msgP = $('#msg-produto');
  let editandoId = null;

  function abrirProduto(p) {
    editandoId = p ? p.id : null;
    $('#dlg-produto-titulo').textContent = p ? 'Editar item' : 'Novo item';
    form.reset(); msgP.textContent = '';
    const v = p || { nome: '', categoria: 'especial', tag: '', preco: '', rotulo_preco: 'a partir de', ordem: 999, ativo: true, descricao: '', imagem: '' };
    for (const k of ['nome', 'categoria', 'tag', 'preco', 'rotulo_preco', 'ordem', 'descricao', 'imagem']) form[k].value = v[k] ?? '';
    form.ativo.value = v.ativo ? '1' : '0';
    atualizarPrev(v.imagem);
    dlg.showModal();
  }
  function atualizarPrev(url) { const i = $('#prev-img'); i.style.display = url ? 'block' : 'none'; if (url) i.src = url; }
  $('#fechar-produto').addEventListener('click', () => dlg.close());

  form.arquivo.addEventListener('change', async () => {
    if (!form.arquivo.files[0]) return;
    const fd = new FormData(); fd.append('arquivo', form.arquivo.files[0]);
    msgP.className = 'msg'; msgP.textContent = 'Enviando foto…';
    try { const d = await api('POST', '/admin/api/upload', fd); form.imagem.value = d.url; atualizarPrev(d.url); msgP.textContent = ''; }
    catch (e) { msgP.className = 'msg erro'; msgP.textContent = e.message; }
  });

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const corpo = {
      nome: form.nome.value, categoria: form.categoria.value, tag: form.tag.value, preco: form.preco.value,
      rotulo_preco: form.rotulo_preco.value, ordem: form.ordem.value, descricao: form.descricao.value,
      imagem: form.imagem.value, ativo: form.ativo.value === '1',
    };
    try {
      if (editandoId) await api('PUT', `/admin/api/produtos/${editandoId}`, corpo);
      else await api('POST', '/admin/api/produtos', corpo);
      dlg.close(); mostrar();
    } catch (err) { msgP.className = 'msg erro'; msgP.textContent = err.message; }
  });

  async function abaCardapio() {
    const lista = await api('GET', '/admin/api/produtos');
    const linhas = lista.map(p => el('tr', { class: p.ativo ? '' : 'off' },
      el('td', {}, p.imagem ? el('img', { src: p.imagem, alt: '' }) : null),
      el('td', { text: p.nome }),
      el('td', { text: CAT[p.categoria] }),
      el('td', { text: brl(p.preco) }),
      el('td', { text: p.ativo ? 'Visível' : 'Oculto' }),
      el('td', {},
        el('button', { class: 'b sec', text: 'Editar', onclick: () => abrirProduto(p) }), ' ',
        el('button', { class: 'b', text: 'Excluir', onclick: async () => {
          if (!confirm(`Excluir "${p.nome}" do cardápio?`)) return;
          try { await api('DELETE', `/admin/api/produtos/${p.id}`); mostrar(); } catch (e) { falha(e); }
        } }))));
    raiz.replaceChildren(
      el('div', { class: 'linha', style: 'margin-bottom:.8rem' },
        el('strong', { text: `${lista.length} itens` }),
        el('button', { class: 'b ok', text: '+ Novo item', onclick: () => abrirProduto(null) })),
      el('div', { class: 'card tbl-wrap' }, el('table', {},
        el('thead', {}, el('tr', {}, ['', 'Nome', 'Categoria', 'Preço', 'Situação', ''].map(t => el('th', { text: t })))),
        el('tbody', {}, linhas))));
  }

  // ---------------------------------------------------------------- configurações
  async function abaConfig() {
    const c = await api('GET', '/admin/api/config');
    const fWa = el('input', { value: c.whatsapp, inputmode: 'numeric' });
    const fTaxa = el('input', { value: String(c.taxa_entrega).replace('.', ','), inputmode: 'decimal' });
    const m1 = el('p', { class: 'msg' });
    const fAtual = el('input', { type: 'password', autocomplete: 'current-password' });
    const fNova = el('input', { type: 'password', autocomplete: 'new-password' });
    const m2 = el('p', { class: 'msg' });
    const dizer = (m, t, ok) => { m.textContent = t; m.className = 'msg ' + (ok ? 'ok' : 'erro'); };
    raiz.replaceChildren(
      el('div', { class: 'card' }, el('h3', { text: 'Pizzaria' }),
        el('label', { class: 'meta', text: 'WhatsApp que recebe os pedidos (DDI + DDD + número, só dígitos) ' }, fWa), el('br'),
        el('label', { class: 'meta', text: 'Taxa de entrega (R$) ' }, fTaxa), el('br'),
        el('button', { class: 'b ok', text: 'Salvar', onclick: async () => {
          try { await api('PUT', '/admin/api/config', { whatsapp: fWa.value, taxa_entrega: fTaxa.value }); dizer(m1, 'Salvo!', true); }
          catch (e) { dizer(m1, e.message, false); }
        } }), m1),
      el('div', { class: 'card' }, el('h3', { text: 'Trocar senha' }),
        el('label', { class: 'meta', text: 'Senha atual ' }, fAtual), el('br'),
        el('label', { class: 'meta', text: 'Nova senha (mín. 8 caracteres) ' }, fNova), el('br'),
        el('button', { class: 'b ok', text: 'Trocar senha', onclick: async () => {
          try { await api('POST', '/admin/api/senha', { atual: fAtual.value, nova: fNova.value }); fAtual.value = fNova.value = ''; dizer(m2, 'Senha alterada!', true); }
          catch (e) { dizer(m2, e.message, false); }
        } }), m2));
  }

  // ---------------------------------------------------------------- navegação
  const abas = { pedidos: abaPedidos, reservas: abaReservas, avaliacoes: abaAvaliacoes, cardapio: abaCardapio, config: abaConfig };

  async function mostrar() {
    document.querySelectorAll('#abas button').forEach(b => b.classList.toggle('on', b.dataset.aba === aba));
    try { await abas[aba](); } catch (e) { if (e.message !== 'Sessão expirada') raiz.replaceChildren(el('p', { class: 'vazio', text: e.message })); }
    contadores();
  }

  async function contadores() {
    try {
      const [p, r, a] = await Promise.all([
        api('GET', '/admin/api/pedidos?status=novo'), api('GET', '/admin/api/reservas?status=pendente'),
        api('GET', '/admin/api/avaliacoes?status=pendente')]);
      for (const [id, n] of [['pedidos', p.length], ['reservas', r.length], ['avaliacoes', a.length]]) {
        const b = $('#b-' + id); b.textContent = n; b.hidden = n === 0;
      }
    } catch { /* ignora */ }
  }

  document.querySelectorAll('#abas button').forEach(b => b.addEventListener('click', () => { aba = b.dataset.aba; mostrar(); }));
  // Atualiza sozinho a cada 30 s nas telas de acompanhamento (sem atrapalhar edição).
  timer = setInterval(() => { if (!dlg.open && ['pedidos', 'reservas'].includes(aba) && !document.hidden) mostrar(); }, 30000);
  mostrar();
})();
