(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const brl = v => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  // Cria elementos sem innerHTML: textos vindos do banco/clientes nunca viram HTML.
  function el(tag, props = {}, ...filhos) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
    filhos.flat().forEach(f => f != null && e.append(f));
    return e;
  }

  async function api(url, corpo) {
    const opts = corpo ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) } : {};
    let r;
    try { r = await fetch(url, opts); } catch { throw new Error('Sem conexão com o servidor. Tente novamente.'); }
    const d = await r.json().catch(() => ({}));
    if (!r.ok || d.ok === false) throw new Error(d.erro || 'Algo deu errado. Tente novamente.');
    return d;
  }

  const estado = { produtos: [], config: { whatsapp: '554435224245', taxa_entrega: 0 }, filtro: 'todos', carrinho: {} };

  // ------------------------------------------------------------------ carrinho
  function salvarCarrinho() { try { localStorage.setItem('fornetto_carrinho', JSON.stringify(estado.carrinho)); } catch {} }
  function lerCarrinho() {
    try {
      const c = JSON.parse(localStorage.getItem('fornetto_carrinho') || '{}');
      const ids = new Set(estado.produtos.map(p => String(p.id)));
      for (const [id, q] of Object.entries(c)) if (ids.has(id) && Number.isInteger(q) && q > 0) estado.carrinho[id] = Math.min(q, 20);
    } catch {}
  }
  const produtoPorId = id => estado.produtos.find(p => String(p.id) === String(id));
  const totalItens = () => Object.values(estado.carrinho).reduce((a, b) => a + b, 0);
  const subtotal = () => Object.entries(estado.carrinho).reduce((a, [id, q]) => a + (produtoPorId(id)?.preco || 0) * q, 0);

  function mudarQtd(id, delta) {
    const nova = Math.max(0, Math.min(20, (estado.carrinho[id] || 0) + delta));
    if (nova) estado.carrinho[id] = nova; else delete estado.carrinho[id];
    salvarCarrinho();
    atualizarTudo();
  }

  function atualizarTudo() {
    document.querySelectorAll('[data-qtd-de]').forEach(s => { s.textContent = estado.carrinho[s.dataset.qtdDe] || 0; });
    const n = totalItens(), barra = $('#barra-carrinho');
    barra.hidden = n === 0;
    $('#carrinho-resumo').textContent = `Ver pedido (${n}) · ${brl(subtotal())}`;
    if ($('#dlg-pedido').open && !$('#pedido-passo1').hidden) renderPedido();
  }

  // ------------------------------------------------------------------ cardápio
  function renderMenu() {
    const grade = $('#menu-grid');
    grade.replaceChildren();
    const lista = estado.produtos.filter(p => estado.filtro === 'todos' || p.categoria === estado.filtro);
    if (!lista.length) { grade.append(el('p', { class: 'msg-carregando', text: 'Nenhum item nesta categoria.' })); return; }
    for (const p of lista) {
      const rodizio = p.categoria === 'rodizio';
      const acao = rodizio
        ? el('button', { class: 'btn-pedir', type: 'button', text: 'Reservar', onclick: abrirReserva })
        : el('span', { class: 'qtd-box' },
            el('button', { type: 'button', 'aria-label': `Remover ${p.nome}`, text: '−', onclick: () => mudarQtd(p.id, -1) }),
            el('span', { 'data-qtd-de': p.id, text: estado.carrinho[p.id] || 0 }),
            el('button', { type: 'button', 'aria-label': `Adicionar ${p.nome}`, text: '+', onclick: () => mudarQtd(p.id, 1) }));
      const rotulo = p.rotulo_preco === 'por pessoa' ? ' /p' : '';
      grade.append(el('div', { class: 'card-pizza', 'data-categoria': p.categoria },
        p.imagem ? el('img', { src: p.imagem, alt: `Pizza ${p.nome}`, loading: 'lazy' }) : null,
        el('div', { class: 'card-content' },
          el('div', { class: 'card-title' }, p.nome, p.tag ? el('span', { class: 'card-tag', text: p.tag }) : null),
          el('p', { class: 'card-desc', text: p.descricao }),
          el('div', { class: 'card-footer' },
            el('span', { class: 'price' },
              p.rotulo_preco === 'a partir de' ? el('span', { class: 'preco-rotulo', text: 'a partir de' }) : null,
              brl(p.preco) + rotulo),
            acao))));
    }
  }

  document.querySelectorAll('[data-filtro]').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.btn-filtro').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    estado.filtro = b.dataset.filtro;
    renderMenu();
  }));

  // ------------------------------------------------------------------ pedido
  const dlgPedido = $('#dlg-pedido'), formPedido = $('#form-pedido');

  function msg(form, texto, tipo) {
    const m = $('.form-msg', form);
    m.textContent = texto || '';
    m.className = 'form-msg' + (tipo ? ' ' + tipo : '');
  }

  function renderPedido() {
    const box = $('#itens-carrinho');
    box.replaceChildren();
    const entrega = formPedido.tipo.value === 'entrega';
    $('#lbl-endereco').hidden = !entrega;
    formPedido.endereco.required = entrega;
    for (const [id, q] of Object.entries(estado.carrinho)) {
      const p = produtoPorId(id);
      if (!p) continue;
      box.append(el('div', { class: 'item-carrinho' },
        el('span', { class: 'nome', text: p.nome }),
        el('span', { class: 'qtd-box' },
          el('button', { type: 'button', text: '−', onclick: () => mudarQtd(id, -1) }),
          el('span', { text: q }),
          el('button', { type: 'button', text: '+', onclick: () => mudarQtd(id, 1) })),
        el('span', { text: brl(p.preco * q) })));
    }
    const taxa = entrega ? estado.config.taxa_entrega : 0;
    const t = $('#totais-pedido');
    t.replaceChildren(
      el('div', { text: `Subtotal: ${brl(subtotal())}` }),
      entrega ? el('div', { text: `Entrega: ${brl(taxa)}` }) : null,
      el('div', {}, 'Total: ', el('strong', { text: brl(subtotal() + taxa) })),
      el('div', { class: 'dica', text: 'Valores "a partir de": o tamanho e o valor final são confirmados no WhatsApp.' }));
    if (!totalItens() && dlgPedido.open && !$('#pedido-passo1').hidden) dlgPedido.close();
  }

  $('#barra-carrinho').addEventListener('click', () => {
    $('#pedido-passo1').hidden = false; $('#pedido-passo2').hidden = true;
    msg(formPedido, '');
    renderPedido();
    dlgPedido.showModal();
  });
  formPedido.tipo.addEventListener('change', renderPedido);

  formPedido.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = $('button[type=submit]', formPedido);
    btn.disabled = true; msg(formPedido, 'Enviando…');
    try {
      const d = await api('/api/pedidos', {
        nome: formPedido.nome.value, telefone: formPedido.telefone.value, tipo: formPedido.tipo.value,
        endereco: formPedido.endereco.value, pagamento: formPedido.pagamento.value, observacao: formPedido.observacao.value,
        itens: Object.entries(estado.carrinho).map(([produto_id, qtd]) => ({ produto_id: Number(produto_id), qtd })),
      });
      $('#pedido-ok-txt').textContent = `Pedido #${d.pedido} · total ${brl(d.total)}.`;
      $('#btn-wa-pedido').href = d.whatsapp;
      $('#pedido-passo1').hidden = true; $('#pedido-passo2').hidden = false;
      estado.carrinho = {}; salvarCarrinho(); atualizarTudo(); formPedido.observacao.value = '';
    } catch (err) { msg(formPedido, err.message, 'erro'); }
    btn.disabled = false;
  });

  // ------------------------------------------------------------------ reserva
  const dlgReserva = $('#dlg-reserva'), formReserva = $('#form-reserva');

  function abrirReserva() {
    $('#reserva-passo1').hidden = false; $('#reserva-passo2').hidden = true;
    msg(formReserva, '');
    const hoje = new Date(); hoje.setMinutes(hoje.getMinutes() - hoje.getTimezoneOffset());
    formReserva.data.min = hoje.toISOString().slice(0, 10);
    dlgReserva.showModal();
  }
  document.querySelectorAll('[data-abrir-reserva]').forEach(b => b.addEventListener('click', abrirReserva));

  const selH = $('#sel-horario');
  for (let m = 18 * 60 + 30; m <= 22 * 60 + 30; m += 30) {
    const h = `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
    selH.append(el('option', { value: h, text: h }));
  }

  formReserva.addEventListener('submit', async e => {
    e.preventDefault();
    const dia = new Date(formReserva.data.value + 'T12:00:00').getDay();
    if (dia !== 3 && dia !== 5) { msg(formReserva, 'O rodízio acontece apenas às quartas e sextas.', 'erro'); return; }
    const btn = $('button[type=submit]', formReserva);
    btn.disabled = true; msg(formReserva, 'Enviando…');
    try {
      const d = await api('/api/reservas', Object.fromEntries(new FormData(formReserva)));
      $('#btn-wa-reserva').href = d.whatsapp;
      $('#reserva-passo1').hidden = true; $('#reserva-passo2').hidden = false;
    } catch (err) { msg(formReserva, err.message, 'erro'); }
    btn.disabled = false;
  });

  // ------------------------------------------------------------------ avaliações
  function renderAvaliacoes(lista) {
    const box = $('#reviews-list');
    box.replaceChildren(...lista.map(a => el('div', { class: 'review-card' },
      el('div', {}, el('span', { class: 'review-stars', text: '★'.repeat(a.estrelas) }), el('strong', { text: ` - ${a.nome}` })),
      el('p', { text: `"${a.texto}"` }))));
  }
  const formAv = $('#form-avaliacao');
  formAv.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = $('button[type=submit]', formAv);
    btn.disabled = true; msg(formAv, 'Enviando…');
    try {
      const d = await api('/api/avaliacoes', Object.fromEntries(new FormData(formAv)));
      msg(formAv, d.mensagem || 'Obrigado!', 'ok'); formAv.reset();
    } catch (err) { msg(formAv, err.message, 'erro'); }
    btn.disabled = false;
  });

  // ------------------------------------------------------------------ WhatsApp e status da loja
  function ajustarWhatsApp() {
    document.querySelectorAll('a[data-wa]').forEach(a => {
      a.href = `https://wa.me/${estado.config.whatsapp}?text=${encodeURIComponent(a.dataset.wa)}`;
    });
  }

  function statusLoja() {
    const partes = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Sao_Paulo', weekday: 'short', hour: 'numeric', minute: 'numeric', hour12: false })
      .formatToParts(new Date());
    const g = t => partes.find(p => p.type === t).value;
    const dia = g('weekday'), min = (Number(g('hour')) % 24) * 60 + Number(g('minute'));
    const aberto = dia === 'Sat' ? min >= 21 * 60 + 30 : (min >= 18 * 60 + 30 && min < 23 * 60);
    const s = $('#hero-status');
    s.textContent = aberto ? 'Aberto agora' : 'Fechado no momento';
    s.style.backgroundColor = aberto ? '#2a9d8f' : '#6c757d';
  }

  // ------------------------------------------------------------------ início
  async function iniciar() {
    statusLoja();
    try {
      const [prods, conf, avs] = await Promise.all([api('/api/produtos'), api('/api/config'), api('/api/avaliacoes')]);
      estado.produtos = prods; estado.config = conf;
      lerCarrinho(); ajustarWhatsApp(); renderAvaliacoes(avs);
    } catch (err) {
      $('#menu-grid').replaceChildren(el('p', { class: 'msg-carregando', text: err.message }));
      return;
    }
    renderMenu(); atualizarTudo();
  }
  iniciar();
})();
