"""Back-end da Pizzaria Fornetto (Flask + SQLite).

Rodar:  python app.py          (desenvolvimento, porta 5000)
Senha:  python app.py set-password
"""
import json
import os
import re
import secrets
import sqlite3
import sys
import time
import uuid
from datetime import date, datetime, timedelta
from functools import wraps
from urllib.parse import quote

from flask import Flask, abort, g, jsonify, redirect, render_template, request, session, url_for
from PIL import Image
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("DATA_DIR", os.path.join(BASE, "instance"))
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "fornetto.db")
UPLOAD_DIR = os.path.join(BASE, "static", "img")
os.makedirs(UPLOAD_DIR, exist_ok=True)

WHATSAPP_PADRAO = "554435224245"
CATEGORIAS = ("tradicional", "especial", "veggie", "doce", "rodizio")
STATUS_PEDIDO = ("novo", "em_preparo", "saiu_entrega", "concluido", "cancelado")
STATUS_RESERVA = ("pendente", "confirmada", "cancelada")
STATUS_AVALIACAO = ("pendente", "aprovada", "rejeitada")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 6 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=8)


def _secret_key():
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    path = os.path.join(DATA_DIR, "secret_key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
        os.chmod(path, 0o600)
    return open(path).read().strip()


app.secret_key = _secret_key()

# --------------------------------------------------------------------------- banco

SCHEMA = """
CREATE TABLE IF NOT EXISTS config (chave TEXT PRIMARY KEY, valor TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS produtos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL, categoria TEXT NOT NULL, tag TEXT NOT NULL DEFAULT '',
  descricao TEXT NOT NULL DEFAULT '', preco REAL NOT NULL,
  rotulo_preco TEXT NOT NULL DEFAULT '', imagem TEXT NOT NULL DEFAULT '',
  ativo INTEGER NOT NULL DEFAULT 1, ordem INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS pedidos (
  id INTEGER PRIMARY KEY AUTOINCREMENT, criado_em TEXT NOT NULL,
  nome TEXT NOT NULL, telefone TEXT NOT NULL, tipo TEXT NOT NULL,
  endereco TEXT NOT NULL DEFAULT '', pagamento TEXT NOT NULL DEFAULT '',
  observacao TEXT NOT NULL DEFAULT '', subtotal REAL NOT NULL,
  taxa_entrega REAL NOT NULL DEFAULT 0, total REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'novo'
);
CREATE TABLE IF NOT EXISTS pedido_itens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pedido_id INTEGER NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  produto_id INTEGER, nome TEXT NOT NULL, preco REAL NOT NULL, qtd INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reservas (
  id INTEGER PRIMARY KEY AUTOINCREMENT, criado_em TEXT NOT NULL,
  nome TEXT NOT NULL, telefone TEXT NOT NULL, data TEXT NOT NULL,
  horario TEXT NOT NULL, pessoas INTEGER NOT NULL,
  observacao TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pendente'
);
CREATE TABLE IF NOT EXISTS avaliacoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, criado_em TEXT NOT NULL,
  nome TEXT NOT NULL, estrelas INTEGER NOT NULL, texto TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pendente'
);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def get_config(db, chave, padrao=None):
    row = db.execute("SELECT valor FROM config WHERE chave = ?", (chave,)).fetchone()
    return row["valor"] if row else padrao


def set_config(db, chave, valor):
    db.execute("INSERT INTO config (chave, valor) VALUES (?, ?) "
               "ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor", (chave, str(valor)))


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.executescript(SCHEMA)
    agora = datetime.now().isoformat(timespec="seconds")
    seed_path = os.path.join(BASE, "seed_data.json")
    if db.execute("SELECT COUNT(*) FROM produtos").fetchone()[0] == 0 and os.path.exists(seed_path):
        seed = json.load(open(seed_path, encoding="utf-8"))
        for p in seed["produtos"]:
            db.execute(
                "INSERT INTO produtos (nome, categoria, tag, descricao, preco, rotulo_preco, imagem, ordem) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (p["nome"], p["categoria"], p["tag"], p["descricao"], p["preco"],
                 p["rotulo_preco"], p["imagem"], p["ordem"]))
        for a in seed["avaliacoes"]:
            db.execute("INSERT INTO avaliacoes (criado_em, nome, estrelas, texto, status) "
                       "VALUES (?,?,?,?, 'aprovada')", (agora, a["nome"], a["estrelas"], a["texto"]))
    # Bancos criados antes da foto real da Calabresa: troca o placeholder externo pela foto local.
    db.execute("UPDATE produtos SET imagem = '/static/img/calabresa.jpg' "
               "WHERE nome = 'Calabresa' AND imagem LIKE 'https://images.unsplash.com/%'")
    if get_config(db, "whatsapp") is None:
        set_config(db, "whatsapp", WHATSAPP_PADRAO)
    if get_config(db, "taxa_entrega") is None:
        set_config(db, "taxa_entrega", "0")
    if get_config(db, "admin_hash") is None:
        senha = os.environ.get("ADMIN_PASSWORD")
        gerada = senha is None
        if gerada:
            senha = secrets.token_urlsafe(9)
        set_config(db, "admin_hash", generate_password_hash(senha))
        if gerada:
            print(f"\n*** Senha do painel admin (guarde, aparece só agora): {senha} ***\n"
                  "    Para trocar: python app.py set-password\n", flush=True)
    db.commit()
    db.close()


# --------------------------------------------------------------------------- utilitários

_hits = {}


def limitar(chave, maximo, janela):
    """Limite simples por IP em memória (suficiente para um único processo)."""
    agora = time.time()
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()
    k = (chave, ip)
    _hits[k] = [t for t in _hits.get(k, []) if agora - t < janela]
    if len(_hits[k]) >= maximo:
        return False
    _hits[k].append(agora)
    return True


def erro(msg, codigo=400):
    return jsonify(ok=False, erro=msg), codigo


def dados_json():
    d = request.get_json(silent=True)
    return d if isinstance(d, dict) else None


def texto(v, maximo):
    return re.sub(r"\s+", " ", str(v or "")).strip()[:maximo]


def telefone_ok(v):
    d = re.sub(r"\D", "", str(v or ""))
    return d if 10 <= len(d) <= 13 else None


def brl(v):
    return "R$ " + f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def link_whatsapp(db, msg):
    return f"https://wa.me/{get_config(db, 'whatsapp', WHATSAPP_PADRAO)}?text={quote(msg)}"


def produto_dict(r):
    d = dict(r)
    d["ativo"] = bool(d["ativo"])
    return d


# --------------------------------------------------------------------------- site público

@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/produtos")
def api_produtos():
    rows = get_db().execute("SELECT * FROM produtos WHERE ativo = 1 ORDER BY ordem, id").fetchall()
    return jsonify([produto_dict(r) for r in rows])


@app.get("/api/config")
def api_config():
    db = get_db()
    return jsonify(whatsapp=get_config(db, "whatsapp"), taxa_entrega=float(get_config(db, "taxa_entrega", "0")))


@app.get("/api/avaliacoes")
def api_avaliacoes():
    rows = get_db().execute(
        "SELECT nome, estrelas, texto FROM avaliacoes WHERE status = 'aprovada' ORDER BY id DESC LIMIT 30"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


@app.post("/api/avaliacoes")
def api_nova_avaliacao():
    d = dados_json()
    if d is None:
        return erro("Requisição inválida.")
    if d.get("site"):  # honeypot: campo escondido que só robôs preenchem
        return jsonify(ok=True)
    if not limitar("avaliacao", 3, 3600):
        return erro("Muitas avaliações enviadas. Tente novamente mais tarde.", 429)
    nome, msg = texto(d.get("nome"), 60), texto(d.get("texto"), 500)
    try:
        estrelas = int(d.get("estrelas"))
    except (TypeError, ValueError):
        estrelas = 0
    if len(nome) < 2 or len(msg) < 10 or not 1 <= estrelas <= 5:
        return erro("Informe nome, nota de 1 a 5 e um comentário com pelo menos 10 caracteres.")
    db = get_db()
    db.execute("INSERT INTO avaliacoes (criado_em, nome, estrelas, texto) VALUES (?,?,?,?)",
               (datetime.now().isoformat(timespec="seconds"), nome, estrelas, msg))
    db.commit()
    return jsonify(ok=True, mensagem="Obrigado! Sua avaliação aparecerá no site após aprovação.")


@app.post("/api/pedidos")
def api_novo_pedido():
    d = dados_json()
    if d is None:
        return erro("Requisição inválida.")
    if not limitar("pedido", 10, 3600):
        return erro("Muitos pedidos em pouco tempo. Tente novamente mais tarde.", 429)
    nome = texto(d.get("nome"), 80)
    tel = telefone_ok(d.get("telefone"))
    tipo = d.get("tipo")
    endereco = texto(d.get("endereco"), 200)
    pagamento = texto(d.get("pagamento"), 40)
    obs = texto(d.get("observacao"), 300)
    itens_in = d.get("itens")
    if len(nome) < 2:
        return erro("Informe seu nome.")
    if not tel:
        return erro("Informe um telefone válido com DDD.")
    if tipo not in ("entrega", "retirada"):
        return erro("Escolha entrega ou retirada.")
    if tipo == "entrega" and len(endereco) < 8:
        return erro("Informe o endereço de entrega.")
    if not isinstance(itens_in, list) or not 1 <= len(itens_in) <= 40:
        return erro("O pedido precisa ter pelo menos um item.")

    db = get_db()
    linhas, subtotal = [], 0.0
    for it in itens_in:
        try:
            pid, qtd = int(it.get("produto_id")), int(it.get("qtd"))
        except (TypeError, ValueError, AttributeError):
            return erro("Item inválido.")
        if not 1 <= qtd <= 20:
            return erro("Quantidade inválida (1 a 20).")
        p = db.execute("SELECT * FROM produtos WHERE id = ? AND ativo = 1 AND categoria != 'rodizio'",
                       (pid,)).fetchone()
        if not p:
            return erro("Um dos itens não está mais disponível. Atualize a página.")
        linhas.append((p, qtd))
        subtotal += p["preco"] * qtd  # preço sempre vem do banco, nunca do navegador
    taxa = float(get_config(db, "taxa_entrega", "0")) if tipo == "entrega" else 0.0
    total = subtotal + taxa

    cur = db.execute(
        "INSERT INTO pedidos (criado_em, nome, telefone, tipo, endereco, pagamento, observacao, subtotal, taxa_entrega, total) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        (datetime.now().isoformat(timespec="seconds"), nome, tel, tipo, endereco, pagamento, obs, subtotal, taxa, total))
    pid = cur.lastrowid
    for p, qtd in linhas:
        db.execute("INSERT INTO pedido_itens (pedido_id, produto_id, nome, preco, qtd) VALUES (?,?,?,?,?)",
                   (pid, p["id"], p["nome"], p["preco"], qtd))
    db.commit()

    msg = [f"*Novo pedido #{pid}*", f"Nome: {nome}", f"Telefone: {tel}", ""]
    msg += [f"{q}x {p['nome']} - {brl(p['preco'] * q)}" for p, q in linhas]
    msg += ["", f"Subtotal: {brl(subtotal)}"]
    if tipo == "entrega":
        msg += [f"Taxa de entrega: {brl(taxa)}", f"Endereço: {endereco}"]
    else:
        msg += ["Retirada no local"]
    msg += [f"*Total: {brl(total)}*"]
    if pagamento:
        msg += [f"Pagamento: {pagamento}"]
    if obs:
        msg += [f"Obs: {obs}"]
    msg += ["", "(Valores 'a partir de': confirmar tamanho e valor final.)"]
    return jsonify(ok=True, pedido=pid, total=total, whatsapp=link_whatsapp(db, "\n".join(msg)))


def validar_reserva(d):
    nome, obs = texto(d.get("nome"), 80), texto(d.get("observacao"), 300)
    tel = telefone_ok(d.get("telefone"))
    try:
        pessoas = int(d.get("pessoas"))
        dia = date.fromisoformat(str(d.get("data")))
        h, m = map(int, str(d.get("horario")).split(":"))
    except (TypeError, ValueError):
        return None, "Preencha data, horário e número de pessoas corretamente."
    if len(nome) < 2:
        return None, "Informe seu nome."
    if not tel:
        return None, "Informe um telefone válido com DDD."
    if not 1 <= pessoas <= 30:
        return None, "Número de pessoas deve ser de 1 a 30."
    if dia < date.today():
        return None, "Escolha uma data a partir de hoje."
    if dia > date.today() + timedelta(days=90):
        return None, "Reservas só com até 90 dias de antecedência."
    if dia.weekday() not in (2, 4):  # quarta=2, sexta=4
        return None, "O rodízio acontece apenas às quartas e sextas."
    if not (0 <= h < 24 and 0 <= m < 60) or not (18 * 60 + 30 <= h * 60 + m <= 22 * 60 + 30):
        return None, "Horário de reservas: entre 18:30 e 22:30."
    return dict(nome=nome, tel=tel, dia=dia, horario=f"{h:02d}:{m:02d}", pessoas=pessoas, obs=obs), None


@app.post("/api/reservas")
def api_nova_reserva():
    d = dados_json()
    if d is None:
        return erro("Requisição inválida.")
    if not limitar("reserva", 10, 3600):
        return erro("Muitas solicitações em pouco tempo. Tente novamente mais tarde.", 429)
    r, msg_erro = validar_reserva(d)
    if msg_erro:
        return erro(msg_erro)
    db = get_db()
    cur = db.execute(
        "INSERT INTO reservas (criado_em, nome, telefone, data, horario, pessoas, observacao) VALUES (?,?,?,?,?,?,?)",
        (datetime.now().isoformat(timespec="seconds"), r["nome"], r["tel"], r["dia"].isoformat(),
         r["horario"], r["pessoas"], r["obs"]))
    db.commit()
    msg = [f"*Reserva do Rodízio #{cur.lastrowid}*", f"Nome: {r['nome']}", f"Telefone: {r['tel']}",
           f"Data: {r['dia'].strftime('%d/%m/%Y')} às {r['horario']}", f"Pessoas: {r['pessoas']}"]
    if r["obs"]:
        msg.append(f"Obs: {r['obs']}")
    return jsonify(ok=True, reserva=cur.lastrowid, whatsapp=link_whatsapp(db, "\n".join(msg)))


# --------------------------------------------------------------------------- admin

def admin_required(f):
    @wraps(f)
    def wrap(*a, **kw):
        if not session.get("admin"):
            if request.path.startswith("/admin/api/"):
                return erro("Sessão expirada. Entre novamente.", 401)
            return redirect(url_for("admin_login"))
        if request.method not in ("GET", "HEAD") and \
                not secrets.compare_digest(request.headers.get("X-CSRF-Token", ""), session.get("csrf", "x")):
            return erro("Token de segurança inválido. Recarregue a página.", 403)
        return f(*a, **kw)
    return wrap


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    msg = ""
    if request.method == "POST":
        if not limitar("login", 5, 600):
            msg = "Muitas tentativas. Aguarde 10 minutos."
        elif check_password_hash(get_config(get_db(), "admin_hash", ""), request.form.get("senha", "")):
            session.clear()
            session.permanent = True
            session["admin"] = True
            session["csrf"] = secrets.token_hex(16)
            return redirect(url_for("admin_painel"))
        else:
            msg = "Senha incorreta."
    return render_template("admin_login.html", msg=msg)


@app.post("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))


@app.get("/admin")
@admin_required
def admin_painel():
    return render_template("admin.html", csrf=session["csrf"])


@app.get("/admin/api/produtos")
@admin_required
def adm_produtos():
    rows = get_db().execute("SELECT * FROM produtos ORDER BY ordem, id").fetchall()
    return jsonify([produto_dict(r) for r in rows])


def ler_produto(d):
    nome = texto(d.get("nome"), 80)
    cat = d.get("categoria")
    try:
        preco = round(float(str(d.get("preco")).replace(",", ".")), 2)
    except ValueError:
        preco = -1
    if len(nome) < 2:
        return None, "Informe o nome."
    if cat not in CATEGORIAS:
        return None, "Categoria inválida."
    if not 0 < preco < 10000:
        return None, "Preço inválido."
    img = str(d.get("imagem") or "").strip()
    if img and not (img.startswith("/static/img/") or img.startswith("https://")):
        return None, "Imagem inválida."
    try:
        ordem = int(d.get("ordem") or 0)
    except ValueError:
        ordem = 0
    return (nome, cat, texto(d.get("tag"), 20), texto(d.get("descricao"), 400), preco,
            texto(d.get("rotulo_preco"), 20), img, 1 if d.get("ativo", True) else 0, ordem), None


@app.post("/admin/api/produtos")
@admin_required
def adm_produto_novo():
    vals, e = ler_produto(dados_json() or {})
    if e:
        return erro(e)
    db = get_db()
    cur = db.execute("INSERT INTO produtos (nome, categoria, tag, descricao, preco, rotulo_preco, imagem, ativo, ordem) "
                     "VALUES (?,?,?,?,?,?,?,?,?)", vals)
    db.commit()
    return jsonify(ok=True, id=cur.lastrowid)


@app.put("/admin/api/produtos/<int:pid>")
@admin_required
def adm_produto_editar(pid):
    vals, e = ler_produto(dados_json() or {})
    if e:
        return erro(e)
    db = get_db()
    cur = db.execute("UPDATE produtos SET nome=?, categoria=?, tag=?, descricao=?, preco=?, rotulo_preco=?, "
                     "imagem=?, ativo=?, ordem=? WHERE id=?", vals + (pid,))
    db.commit()
    return jsonify(ok=True) if cur.rowcount else erro("Produto não encontrado.", 404)


@app.delete("/admin/api/produtos/<int:pid>")
@admin_required
def adm_produto_excluir(pid):
    db = get_db()
    db.execute("DELETE FROM produtos WHERE id = ?", (pid,))  # itens de pedidos antigos guardam nome/preço próprios
    db.commit()
    return jsonify(ok=True)


@app.post("/admin/api/upload")
@admin_required
def adm_upload():
    f = request.files.get("arquivo")
    if not f:
        return erro("Nenhum arquivo enviado.")
    try:
        img = Image.open(f.stream)
        img.verify()
        f.stream.seek(0)
        img = Image.open(f.stream).convert("RGB")
    except Exception:
        return erro("Arquivo não é uma imagem válida (use JPG, PNG ou WEBP).")
    img.thumbnail((900, 900))
    nome = f"{uuid.uuid4().hex}.jpg"
    img.save(os.path.join(UPLOAD_DIR, nome), "JPEG", quality=82, optimize=True)
    return jsonify(ok=True, url=f"/static/img/{nome}")


def _lista_com_status(tabela, validos, ordem="id DESC", limite=200):
    status = request.args.get("status")
    db = get_db()
    if status in validos:
        return db.execute(f"SELECT * FROM {tabela} WHERE status = ? ORDER BY {ordem} LIMIT {limite}", (status,)).fetchall()
    return db.execute(f"SELECT * FROM {tabela} ORDER BY {ordem} LIMIT {limite}").fetchall()


def _mudar_status(tabela, validos, rid):
    st = (dados_json() or {}).get("status")
    if st not in validos:
        return erro("Status inválido.")
    db = get_db()
    cur = db.execute(f"UPDATE {tabela} SET status = ? WHERE id = ?", (st, rid))
    db.commit()
    return jsonify(ok=True) if cur.rowcount else erro("Registro não encontrado.", 404)


@app.get("/admin/api/pedidos")
@admin_required
def adm_pedidos():
    db = get_db()
    out = []
    for p in _lista_com_status("pedidos", STATUS_PEDIDO):
        d = dict(p)
        d["itens"] = [dict(i) for i in db.execute(
            "SELECT nome, preco, qtd FROM pedido_itens WHERE pedido_id = ?", (p["id"],))]
        out.append(d)
    return jsonify(out)


@app.patch("/admin/api/pedidos/<int:rid>")
@admin_required
def adm_pedido_status(rid):
    return _mudar_status("pedidos", STATUS_PEDIDO, rid)


@app.get("/admin/api/reservas")
@admin_required
def adm_reservas():
    return jsonify([dict(r) for r in _lista_com_status("reservas", STATUS_RESERVA, "data DESC, horario DESC")])


@app.patch("/admin/api/reservas/<int:rid>")
@admin_required
def adm_reserva_status(rid):
    return _mudar_status("reservas", STATUS_RESERVA, rid)


@app.get("/admin/api/avaliacoes")
@admin_required
def adm_avaliacoes():
    return jsonify([dict(r) for r in _lista_com_status("avaliacoes", STATUS_AVALIACAO)])


@app.patch("/admin/api/avaliacoes/<int:rid>")
@admin_required
def adm_avaliacao_status(rid):
    return _mudar_status("avaliacoes", STATUS_AVALIACAO, rid)


@app.delete("/admin/api/avaliacoes/<int:rid>")
@admin_required
def adm_avaliacao_excluir(rid):
    db = get_db()
    db.execute("DELETE FROM avaliacoes WHERE id = ?", (rid,))
    db.commit()
    return jsonify(ok=True)


@app.get("/admin/api/config")
@admin_required
def adm_config_ler():
    db = get_db()
    return jsonify(whatsapp=get_config(db, "whatsapp"), taxa_entrega=float(get_config(db, "taxa_entrega", "0")))


@app.put("/admin/api/config")
@admin_required
def adm_config_salvar():
    d = dados_json() or {}
    wa = re.sub(r"\D", "", str(d.get("whatsapp", "")))
    try:
        taxa = round(float(str(d.get("taxa_entrega", 0)).replace(",", ".")), 2)
    except ValueError:
        taxa = -1
    if not 10 <= len(wa) <= 13 or not 0 <= taxa < 500:
        return erro("WhatsApp (com DDI+DDD) ou taxa inválidos.")
    db = get_db()
    set_config(db, "whatsapp", wa)
    set_config(db, "taxa_entrega", taxa)
    db.commit()
    return jsonify(ok=True)


@app.post("/admin/api/senha")
@admin_required
def adm_trocar_senha():
    d = dados_json() or {}
    db = get_db()
    if not check_password_hash(get_config(db, "admin_hash", ""), str(d.get("atual", ""))):
        return erro("Senha atual incorreta.")
    nova = str(d.get("nova", ""))
    if len(nova) < 8:
        return erro("A nova senha precisa ter pelo menos 8 caracteres.")
    set_config(db, "admin_hash", generate_password_hash(nova))
    db.commit()
    return jsonify(ok=True)


@app.after_request
def cabecalhos(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    if request.path.startswith("/admin"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


init_db()

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "set-password":
        import getpass
        nova = getpass.getpass("Nova senha do admin (mín. 8 caracteres): ")
        if len(nova) < 8:
            sys.exit("Senha muito curta.")
        c = sqlite3.connect(DB_PATH)
        set_config(c, "admin_hash", generate_password_hash(nova))
        c.commit()
        print("Senha atualizada.")
    else:
        app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
