# Pizzaria Fornetto — site + back-end

Flask + SQLite. O site público e o painel do dono rodam no mesmo servidor.

## Rodar no computador
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
- Site: http://localhost:5000
- Painel: http://localhost:5000/admin

Na **primeira execução** o programa mostra uma senha aleatória do painel no terminal (aparece só uma vez).
Para definir a sua: `python app.py set-password`
(ou, antes da primeira execução, `ADMIN_PASSWORD=suasenha python app.py`).
Também dá para trocar em **Painel → Configurações**.

## O que o back-end faz
| Recurso | Site | Painel (/admin) |
|---|---|---|
| Cardápio | lido do banco (`/api/produtos`) | criar, editar, ocultar, excluir, trocar foto e preço |
| Pedidos | carrinho → salva no banco → abre WhatsApp com o resumo | lista, muda status (novo, em preparo, saiu p/ entrega, concluído, cancelado) |
| Reservas do rodízio | formulário (só quarta e sexta, 18:30–22:30) | confirmar / cancelar |
| Avaliações | formulário; só aparecem após aprovação | aprovar, rejeitar, excluir |
| Configurações | — | número do WhatsApp, taxa de entrega, senha |

Segurança: o **preço é sempre recalculado no servidor** (o navegador não consegue alterar valores), senha com hash, sessão com token CSRF, limite de envios por IP, campo anti-robô nas avaliações, upload de foto validado e redimensionado.

## Colocar no ar
Use uma hospedagem que rode Python (Render, Railway, VPS, PythonAnywhere…). Hospedagem só de HTML não serve.
```bash
pip install -r requirements.txt
SECRET_KEY=um-texto-longo-e-aleatorio COOKIE_SECURE=1 gunicorn -w 1 -b 0.0.0.0:8000 app:app
```
- Use **1 worker** (`-w 1`): os limites de envio ficam em memória.
- Use HTTPS (`COOKIE_SECURE=1`).
- Variáveis opcionais: `DATA_DIR` (pasta do banco, padrão `instance/`), `PORT`.
- **Disco persistente:** guarde `DATA_DIR` e `static/img/` em disco que não apague a cada deploy.

## Backup
Copie `instance/fornetto.db` e a pasta `static/img/`.

## Observações
- Os preços do cardápio são "a partir de": o tamanho/valor final é confirmado no WhatsApp (o pedido avisa isso).
- A taxa de entrega começa em R$ 0,00 — ajuste em Configurações.
- `seed_data.json` só é usado na primeira execução para carregar o cardápio inicial.
